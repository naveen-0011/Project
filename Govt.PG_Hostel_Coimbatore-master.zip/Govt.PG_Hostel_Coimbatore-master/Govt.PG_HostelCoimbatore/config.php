<?php
$servername = "localhost";
$username = "root";
$password = " ";
$dbname = "registration";

$conn=mysqli_connect("localhost","root"," ","registration") or die("unable to connect");
?>